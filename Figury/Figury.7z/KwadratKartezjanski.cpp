#include "KwadratKartezjanski.h"

KwadratKartezjanski::KwadratKartezjanski(double x, double y, int dlugosc)
{
	p1 = new Punkt(x, y);
}

KwadratKartezjanski::KwadratKartezjanski(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4)
{
}

KwadratKartezjanski::~KwadratKartezjanski()
{
}
